package com.badlogic.gdx.backends.android;

import android.content.Intent;

public interface AndroidEventListener {
  void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent);
}


/* Location:              /home/r00tus3r/ctfs/2020/alles/re/prehistoric-mario-dex2jar.jar!/com/badlogic/gdx/backends/android/AndroidEventListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */