package com.badlogic.gdx.backends.android;

public interface AndroidWallpaperListener {
  void iconDropped(int paramInt1, int paramInt2);
  
  void offsetChange(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, int paramInt2);
  
  void previewStateChange(boolean paramBoolean);
}


/* Location:              /home/r00tus3r/ctfs/2020/alles/re/prehistoric-mario-dex2jar.jar!/com/badlogic/gdx/backends/android/AndroidWallpaperListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */