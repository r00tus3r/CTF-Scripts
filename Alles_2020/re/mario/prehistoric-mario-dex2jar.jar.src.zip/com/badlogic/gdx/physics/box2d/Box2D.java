package com.badlogic.gdx.physics.box2d;

import com.badlogic.gdx.utils.SharedLibraryLoader;

public final class Box2D {
  public static void init() { (new SharedLibraryLoader()).load("gdx-box2d"); }
}


/* Location:              /home/r00tus3r/ctfs/2020/alles/re/prehistoric-mario-dex2jar.jar!/com/badlogic/gdx/physics/box2d/Box2D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */