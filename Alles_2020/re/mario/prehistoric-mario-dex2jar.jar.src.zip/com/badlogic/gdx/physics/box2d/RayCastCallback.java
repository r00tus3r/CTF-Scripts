package com.badlogic.gdx.physics.box2d;

import com.badlogic.gdx.math.Vector2;

public interface RayCastCallback {
  float reportRayFixture(Fixture paramFixture, Vector2 paramVector21, Vector2 paramVector22, float paramFloat);
}


/* Location:              /home/r00tus3r/ctfs/2020/alles/re/prehistoric-mario-dex2jar.jar!/com/badlogic/gdx/physics/box2d/RayCastCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */