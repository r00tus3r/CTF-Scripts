package com.badlogic.gdx.physics.box2d;

import com.badlogic.gdx.math.Vector2;

public class MassData {
  public float I;
  
  public final Vector2 center = new Vector2();
  
  public float mass;
}


/* Location:              /home/r00tus3r/ctfs/2020/alles/re/prehistoric-mario-dex2jar.jar!/com/badlogic/gdx/physics/box2d/MassData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */