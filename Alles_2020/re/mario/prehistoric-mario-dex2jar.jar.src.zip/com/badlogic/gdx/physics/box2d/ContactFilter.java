package com.badlogic.gdx.physics.box2d;

public interface ContactFilter {
  boolean shouldCollide(Fixture paramFixture1, Fixture paramFixture2);
}


/* Location:              /home/r00tus3r/ctfs/2020/alles/re/prehistoric-mario-dex2jar.jar!/com/badlogic/gdx/physics/box2d/ContactFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */