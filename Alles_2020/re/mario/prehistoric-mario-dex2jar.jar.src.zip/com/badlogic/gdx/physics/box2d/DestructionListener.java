package com.badlogic.gdx.physics.box2d;

public interface DestructionListener {}


/* Location:              /home/r00tus3r/ctfs/2020/alles/re/prehistoric-mario-dex2jar.jar!/com/badlogic/gdx/physics/box2d/DestructionListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */