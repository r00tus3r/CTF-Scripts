package com.badlogic.gdx.graphics.g3d.particles.influencers;

import com.badlogic.gdx.graphics.g3d.particles.ParticleControllerComponent;

public abstract class Influencer extends ParticleControllerComponent {}


/* Location:              /home/r00tus3r/ctfs/2020/alles/re/prehistoric-mario-dex2jar.jar!/com/badlogic/gdx/graphics/g3d/particles/influencers/Influencer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */