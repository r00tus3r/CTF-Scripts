package com.badlogic.gdx.graphics.glutils;

public static enum HdpiMode {
  Logical, Pixels;
  
  static  {
    $VALUES = new HdpiMode[] { Logical, Pixels };
  }
}


/* Location:              /home/r00tus3r/ctfs/2020/alles/re/prehistoric-mario-dex2jar.jar!/com/badlogic/gdx/graphics/glutils/HdpiMode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */