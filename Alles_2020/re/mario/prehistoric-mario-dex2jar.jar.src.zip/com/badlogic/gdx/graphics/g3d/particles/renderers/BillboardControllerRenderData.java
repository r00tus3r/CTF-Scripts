package com.badlogic.gdx.graphics.g3d.particles.renderers;

import com.badlogic.gdx.graphics.g3d.particles.ParallelArray;

public class BillboardControllerRenderData extends ParticleControllerRenderData {
  public ParallelArray.FloatChannel colorChannel;
  
  public ParallelArray.FloatChannel regionChannel;
  
  public ParallelArray.FloatChannel rotationChannel;
  
  public ParallelArray.FloatChannel scaleChannel;
}


/* Location:              /home/r00tus3r/ctfs/2020/alles/re/prehistoric-mario-dex2jar.jar!/com/badlogic/gdx/graphics/g3d/particles/renderers/BillboardControllerRenderData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */