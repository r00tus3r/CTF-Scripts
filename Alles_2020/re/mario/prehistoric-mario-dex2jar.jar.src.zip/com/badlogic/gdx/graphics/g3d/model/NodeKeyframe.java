package com.badlogic.gdx.graphics.g3d.model;

public class NodeKeyframe<T> extends Object {
  public float keytime;
  
  public final T value;
  
  public NodeKeyframe(float paramFloat, T paramT) {
    this.keytime = paramFloat;
    this.value = paramT;
  }
}


/* Location:              /home/r00tus3r/ctfs/2020/alles/re/prehistoric-mario-dex2jar.jar!/com/badlogic/gdx/graphics/g3d/model/NodeKeyframe.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */