package com.badlogic.gdx.graphics.g3d.model.data;

public class ModelMeshPart {
  public String id;
  
  public short[] indices;
  
  public int primitiveType;
}


/* Location:              /home/r00tus3r/ctfs/2020/alles/re/prehistoric-mario-dex2jar.jar!/com/badlogic/gdx/graphics/g3d/model/data/ModelMeshPart.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */