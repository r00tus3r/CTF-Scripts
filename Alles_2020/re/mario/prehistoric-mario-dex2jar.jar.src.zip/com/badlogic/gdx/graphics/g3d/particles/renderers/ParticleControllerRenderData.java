package com.badlogic.gdx.graphics.g3d.particles.renderers;

import com.badlogic.gdx.graphics.g3d.particles.ParallelArray;
import com.badlogic.gdx.graphics.g3d.particles.ParticleController;

public abstract class ParticleControllerRenderData {
  public ParticleController controller;
  
  public ParallelArray.FloatChannel positionChannel;
}


/* Location:              /home/r00tus3r/ctfs/2020/alles/re/prehistoric-mario-dex2jar.jar!/com/badlogic/gdx/graphics/g3d/particles/renderers/ParticleControllerRenderData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */