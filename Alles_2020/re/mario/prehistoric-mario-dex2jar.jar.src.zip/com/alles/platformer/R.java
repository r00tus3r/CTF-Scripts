package com.alles.platformer;

public final class R {
  public static final class color {
    public static final int ic_background_color = 2130771968;
  }
  
  public static final class drawable {
    public static final int ic_launcher = 2130837504;
    
    public static final int ic_launcher_background = 2130837505;
    
    public static final int ic_launcher_foreground = 2130837506;
  }
  
  public static final class mipmap {
    public static final int ic_launcher = 2130903040;
    
    public static final int ic_launcher_foreground = 2130903041;
    
    public static final int ic_launcher_round = 2130903042;
  }
  
  public static final class string {
    public static final int app_name = 2130968576;
  }
  
  public static final class style {
    public static final int GdxTheme = 2131034112;
  }
}


/* Location:              /home/r00tus3r/ctfs/2020/alles/re/prehistoric-mario-dex2jar.jar!/com/alles/platformer/R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.6
 */